﻿namespace ProductsApp.Models.Enums
{
    public enum RequestType
    {
        Add,
        Edit,
        Delete
    }
}

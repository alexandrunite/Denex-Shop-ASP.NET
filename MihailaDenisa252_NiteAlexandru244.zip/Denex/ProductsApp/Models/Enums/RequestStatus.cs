﻿namespace ProductsApp.Models.Enums
{
    public enum RequestStatus
    {
        Pending,
        Approved,
        Rejected
    }
}
